# Proyek analisis e-commerce. Jalankan: python analysis.py
# Dependensi: pip install pandas numpy matplotlib seaborn
# Letakkan ZIP di direktori kerja atau set environment ECOMMERCE_ZIP.
import matplotlib
matplotlib.use('Agg')
def display(x):
    print(x.to_string() if hasattr(x, 'to_string') else x)


# # Proyek Analisis Data E-Commerce
# **Analisis penjualan, distribusi pelanggan, pengiriman, dan kepuasan pelanggan**
# 
# Sumber: arsip E-commerce-public-dataset(1).zip yang diunggah pengguna. Seluruh hasil dihitung dari berkas tersebut, tanpa data simulasi. Satuan nilai transaksi ditulis BRL (real Brasil), sesuai konteks dataset e-commerce Brasil; tidak dikonversi menjadi rupiah. Nilai penjualan barang adalah jumlah `price`, bukan laba, pendapatan bersih perusahaan, atau total pembayaran.
# 
# Alur: pertanyaan bisnis → import package → data wrangling (gathering, assessing, cleaning) → EDA → visualization & explanation → analisis lanjutan → conclusion & recommendation.
# 
# **Cara menjalankan:** buka notebook ini di Jupyter/Google Colab. Letakkan ZIP pada direktori kerja, atau ubah `DATA_PATH`. Jika menggunakan Colab, unggah ZIP dengan `from google.colab import files; files.upload()` terlebih dahulu. Jalankan sel berurutan. Dependensi: Python, pandas, numpy, matplotlib, seaborn. Tabel hasil dan gambar tersimpan di folder `hasil_analisis`.

# ## 1. Menentukan Pertanyaan Bisnis
# Periode evaluasi utama: **1 Januari 2017–31 Agustus 2018**, berdasarkan tanggal pembelian. Jendela ini memakai bulan kalender yang tercakup dalam data; bukan jaminan setiap pesanan pada bulan terakhir sudah selesai diamati. Analisis penjualan menggunakan pesanan berstatus delivered pada snapshot dataset, sehingga bulan terbaru berpotensi dipengaruhi waktu penyelesaian pengiriman.
# 
# 1. Bagaimana perubahan jumlah pesanan delivered dan nilai penjualan barang setiap bulan selama Januari 2017–Agustus 2018, serta bulan mana yang tertinggi?
# 2. Kategori produk mana yang memiliki nilai penjualan barang dan jumlah unit tertinggi pada periode tersebut, dan berapa kontribusinya terhadap penjualan?
# 3. Negara bagian pelanggan mana yang menyumbang pesanan delivered terbanyak dan nilai penjualan barang terbesar pada periode tersebut?
# 4. Berapa proporsi pengiriman terlambat pada pesanan delivered yang tanggalnya valid, serta bagaimana perbedaan skor ulasan dan proporsi skor rendah antara pengiriman tepat waktu dan terlambat?
# 5. Analisis lanjutan: bagaimana segmentasi pelanggan berdasarkan Recency, Frequency, dan Monetary untuk transaksi delivered pada periode tersebut?
# 
# Pertanyaan memiliki objek dan ukuran spesifik, dapat dihitung dari tabel yang tersedia, relevan untuk keputusan persediaan dan layanan, serta dibatasi periode historis. Tidak ditetapkan target peningkatan penjualan yang belum didukung eksperimen.

# ## 2. Import Package

from pathlib import Path
from zipfile import ZipFile
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

pd.set_option('display.max_columns', 30)
pd.set_option('display.float_format', lambda x: f'{x:,.2f}')
sns.set_theme(style='whitegrid', palette='deep')
RESULTS = Path('hasil_analisis')
RESULTS.mkdir(exist_ok=True)
START, END = pd.Timestamp('2017-01-01'), pd.Timestamp('2018-09-01')

# ## 3. Data Wrangling — Gathering Data
# Gathering adalah tahap pengumpulan/pembacaan dalam data wrangling. ZIP dibaca langsung sehingga tidak perlu mengekstrak semua file. Awalan kode pos disimpan sebagai string agar nol di depan tidak hilang.
# 
# Grain tabel: customers = ID pelanggan per pesanan (pelanggan yang sama ditautkan dengan customer_unique_id); orders = pesanan; items = barang dalam pesanan; payments = bagian pembayaran; reviews = rekaman ulasan; products = produk; sellers = penjual; geolocation = titik lokasi, bukan kode pos unik; translation = padanan kategori.

DATA_PATH = Path(os.environ.get('ECOMMERCE_ZIP', 'E-commerce-public-dataset(1).zip'))
if not DATA_PATH.exists():
    candidates = list(Path('.').glob('**/E-commerce-public-dataset*.zip'))
    if not candidates:
        raise FileNotFoundError('Unggah ZIP dataset atau ubah DATA_PATH ke lokasi ZIP.')
    DATA_PATH = candidates[0]
raw = {}
with ZipFile(DATA_PATH) as z:
    for name in z.namelist():
        if name.endswith('.csv'):
            key = Path(name).stem.replace('_dataset', '')
            raw[key] = pd.read_csv(z.open(name), dtype={
                'customer_zip_code_prefix':'string',
                'seller_zip_code_prefix':'string',
                'geolocation_zip_code_prefix':'string'})
inventory = pd.DataFrame([{'tabel':k, 'baris':len(v), 'kolom':len(v.columns)} for k,v in raw.items()])
display(inventory)
for name, df in raw.items():
    print(name, ':', ', '.join(df.columns))

# ## 4. Data Wrangling — Assessing Data
# Periksa tipe data, missing value, duplikasi seluruh baris, keunikan primary key, integritas relasi, rentang numerik, dan urutan waktu. Banyak baris untuk satu order_id pada items/payments/reviews tidak otomatis merupakan kesalahan. Missing tanggal pengiriman pada pesanan canceled atau unavailable tidak boleh dianggap sebagai tanggal yang perlu diimputasi.

assessment = pd.DataFrame([{
    'tabel':k, 'baris':len(v), 'duplikat_baris':v.duplicated().sum(),
    'sel_missing':int(v.isna().sum().sum())
} for k,v in raw.items()])
display(assessment)
missing_detail = pd.concat([pd.DataFrame({'tabel':k,'kolom':v.columns,
    'missing':v.isna().sum().values,'persen':v.isna().mean().values*100})
    for k,v in raw.items()], ignore_index=True)
display(missing_detail.query('missing > 0'))
display(raw['orders'].dtypes.rename('tipe_awal').to_frame())
keys = {'customers':['customer_id'], 'orders':['order_id'], 'products':['product_id'],
        'sellers':['seller_id'], 'order_items':['order_id','order_item_id'],
        'order_payments':['order_id','payment_sequential'],
        'product_category_name_translation':['product_category_name']}
display(pd.DataFrame([{'tabel':k,'key':str(key),'duplikat_key':raw[k].duplicated(key).sum()}
                      for k,key in keys.items()]))
print('Jumlah review_id berulang:', raw['order_reviews'].duplicated('review_id').sum())
print('Jumlah order_id berulang pada ulasan:', raw['order_reviews'].duplicated('order_id').sum())
display(raw['orders'].groupby('order_status').agg(
    jumlah=('order_id','size'), tanggal_terima_kosong=('order_delivered_customer_date',lambda x:x.isna().sum())))
for table, cols in {'order_items':['price','freight_value'], 'order_payments':['payment_value','payment_installments'],
                    'products':['product_weight_g','product_length_cm','product_height_cm','product_width_cm'],
                    'order_reviews':['review_score']}.items():
    print(table)
    display(raw[table][cols].describe().T)
relations = [('orders','customer_id','customers','customer_id'),
             ('order_items','order_id','orders','order_id'),
             ('order_items','product_id','products','product_id'),
             ('order_items','seller_id','sellers','seller_id'),
             ('order_payments','order_id','orders','order_id'),
             ('order_reviews','order_id','orders','order_id')]
display(pd.DataFrame([{'relasi':f'{a}.{x} → {b}.{y}', 'baris_tanpa_referensi':(~raw[a][x].isin(raw[b][y])).sum()}
                      for a,x,b,y in relations]))

# ## 5. Data Wrangling — Cleaning Data
# Kebijakan pembersihan:
# - Simpan raw data; hapus hanya duplikat seluruh baris. Pada geolocation, observasi berulang dengan kode pos sama tetapi koordinat berbeda tetap dipertahankan.
# - Konversi tanggal dengan errors='coerce' dan audit kegagalan konversinya. Tanggal hilang tetap NaT; teks ulasan kosong tidak diisi dengan skor atau ulasan buatan.
# - Kategori kosong diberi label unknown. Kategori tanpa padanan Inggris mempertahankan nama aslinya. Dimensi produk kosong/tidak positif ditandai NaN; tidak dipakai dalam analisis utama.
# - Skor ulasan di luar 1–5 ditandai NaN. Harga/ongkir/pembayaran negatif ditandai NaN dan tidak dihitung; nilai nol ditahan karena belum terbukti salah. Outlier positif tidak dihapus tanpa bukti kesalahan.
# - Pilih ulasan paling akhir per order_id berdasarkan review_answer_timestamp, lalu review_creation_date; ini kebijakan eksplisit untuk memperoleh satu skor per pesanan, bukan klaim semua ulasan berulang salah.
# - Agregasikan items dan payments **secara terpisah** per pesanan sebelum join. Gunakan validate agar relasi tidak menggandakan pesanan.
# - Hitung keterlambatan dengan membandingkan **tanggal kalender** penerimaan dengan tanggal estimasi; penerimaan pada hari estimasi tetap tepat waktu. Pesanan delivered dengan tanggal tidak lengkap/urutan mustahil dikeluarkan hanya dari analisis pengiriman, tetap masuk penjualan jika nilai item tersedia.

clean = {k:v.drop_duplicates().copy() for k,v in raw.items()}
conversion_log = []
for name, df in clean.items():
    for col in df.columns:
        if col.endswith('_date') or col.endswith('_timestamp') or col == 'order_approved_at':
            before = df[col].notna()
            converted = pd.to_datetime(df[col], errors='coerce')
            conversion_log.append({'tabel':name,'kolom':col,'gagal_konversi':int((before & converted.isna()).sum())})
            df[col] = converted
    for col in df.select_dtypes(include=['object','string']).columns:
        if any(x in col for x in ['city','state','zip_code']):
            df[col] = df[col].str.strip()
        if 'zip_code_prefix' in col:
            df[col] = df[col].str.zfill(5)
display(pd.DataFrame(conversion_log))
for name, key in keys.items():
    assert not clean[name].duplicated(key).any(), f'Key tidak unik: {name}'
numeric_log = []
for name, cols in {'order_items':['price','freight_value'], 'order_payments':['payment_value']}.items():
    for col in cols:
        bad = clean[name][col] < 0
        numeric_log.append({'tabel':name,'kolom':col,'negatif':int(bad.sum())})
        clean[name].loc[bad,col] = np.nan
products = clean['products'].rename(columns={'product_name_lenght':'product_name_length',
    'product_description_lenght':'product_description_length'}).copy()
for col in ['product_weight_g','product_length_cm','product_height_cm','product_width_cm']:
    products.loc[products[col] <= 0,col] = np.nan
products['product_category_name'] = products['product_category_name'].fillna('unknown')
products = products.merge(clean['product_category_name_translation'], on='product_category_name', how='left', validate='many_to_one')
products['category'] = products['product_category_name_english'].fillna(products['product_category_name'])
reviews = clean['order_reviews'].copy()
reviews.loc[~reviews['review_score'].between(1,5), 'review_score'] = np.nan
reviews = reviews.sort_values(['order_id','review_answer_timestamp','review_creation_date','review_id'], na_position='first')
reviews = reviews.drop_duplicates('order_id',keep='last')
items = clean['order_items'].copy()
item_agg = items.groupby('order_id').agg(item_count=('order_item_id','size'),
    item_sales=('price',lambda x:x.sum(min_count=1)),
    freight_total=('freight_value',lambda x:x.sum(min_count=1)))
payments = clean['order_payments'].groupby('order_id').agg(
    payment_total=('payment_value',lambda x:x.sum(min_count=1)), payment_rows=('payment_sequential','size'))
orders = clean['orders'].merge(clean['customers'],on='customer_id',how='left',validate='many_to_one')
orders = orders.merge(item_agg,on='order_id',how='left',validate='one_to_one')
orders = orders.merge(payments,on='order_id',how='left',validate='one_to_one')
orders = orders.merge(reviews[['order_id','review_score']],on='order_id',how='left',validate='one_to_one')
assert len(orders) == len(clean['orders'])
orders['delivery_days'] = (orders['order_delivered_customer_date'] - orders['order_purchase_timestamp']).dt.total_seconds()/86400
orders['late_days'] = (orders['order_delivered_customer_date'].dt.normalize()-orders['order_estimated_delivery_date'].dt.normalize()).dt.days
orders['delivery_valid'] = (orders['order_delivered_customer_date'].notna() & orders['order_estimated_delivery_date'].notna()
    & orders['order_purchase_timestamp'].notna() & orders['delivery_days'].ge(0)
    & orders['order_estimated_delivery_date'].ge(orders['order_purchase_timestamp'].dt.normalize()))
orders['is_late'] = orders['late_days'].gt(0).where(orders['delivery_valid']).astype('boolean')
period = orders['order_purchase_timestamp'].ge(START) & orders['order_purchase_timestamp'].lt(END)
delivered = orders.loc[period & orders['order_status'].eq('delivered')].copy()
sales_orders = delivered.loc[delivered['item_sales'].notna()].copy()
delivery = delivered.loc[delivered['delivery_valid']].copy()
delivery['is_late'] = delivery['is_late'].astype(bool)
reviewed = delivery.dropna(subset=['review_score']).copy()
reviewed['low_score'] = reviewed['review_score'].le(2)
item_detail = items.merge(products[['product_id','category']],on='product_id',how='left',validate='many_to_one')
item_detail = item_detail.merge(delivered[['order_id','order_purchase_timestamp','customer_state']],on='order_id',how='inner',validate='many_to_one')
# Geolocation tidak diperlukan untuk analisis negara bagian; koordinat tidak dipakai sebagai peta.
# Jika diperlukan, buat satu titik representatif per kode pos dengan median, bukan join titik mentah.
geo_by_zip = clean['geolocation'].groupby('geolocation_zip_code_prefix',as_index=False).agg(
    latitude=('geolocation_lat','median'),longitude=('geolocation_lng','median'))
coverage = pd.DataFrame({'indikator':['Pesanan seluruh snapshot','Pesanan delivered dalam periode',
    'Delivered dengan nilai item','Delivered dengan tanggal pengiriman valid','Tanggal valid dan skor ulasan tersedia',
    'Delivered dikeluarkan dari analisis pengiriman','Delivered tanpa total pembayaran'],
    'jumlah':[len(orders),len(delivered),len(sales_orders),len(delivery),len(reviewed),len(delivered)-len(delivery),delivered['payment_total'].isna().sum()]})
display(coverage)
display(pd.DataFrame(numeric_log))
print('Rentang pembelian snapshot:', orders['order_purchase_timestamp'].min(), 's.d.',orders['order_purchase_timestamp'].max())
print('Jumlah duplikat geolocation yang dihapus:',len(raw['geolocation'])-len(clean['geolocation']))
print('Delivered bertanggal penerimaan sebelum pembelian:', int((delivered['delivery_days']<0).sum()))
print('Carrier sebelum pembelian (audit, tidak dipakai sebagai syarat analisis):',int((orders['order_delivered_carrier_date']<orders['order_purchase_timestamp']).sum()))
print('Persetujuan sebelum pembelian:',int((orders['order_approved_at']<orders['order_purchase_timestamp']).sum()))
print('Selisih total pembayaran - barang - ongkir, median BRL:',
      (delivered['payment_total']-delivered['item_sales']-delivered['freight_total']).median())

# ### Catatan hasil assessing dan cleaning
# Tabel coverage menjelaskan denominator tiap analisis. Nilai pembayaran tidak dianggap sama dengan nilai barang: pembayaran dapat mencakup ongkir, voucher, atau perbedaan pencatatan. Duplikasi geolocation dihapus hanya untuk kebersihan data, bukan untuk mengubah jumlah transaksi. Tidak semua tabel harus digabungkan; sellers dan geolocation tidak diperlukan untuk menjawab pertanyaan utama. Identitas pelanggan berulang memakai customer_unique_id, bukan customer_id.

# ## 6. Exploratory Data Analysis (EDA)

display(orders['order_status'].value_counts().rename_axis('status').reset_index(name='jumlah'))
display(sales_orders[['item_sales','freight_total','payment_total','item_count','delivery_days']].describe().T)
monthly = sales_orders.groupby(sales_orders['order_purchase_timestamp'].dt.to_period('M')).agg(
    orders=('order_id','nunique'), item_sales=('item_sales','sum'), average_order_value=('item_sales','mean'))
monthly = monthly.reindex(pd.period_range('2017-01','2018-08',freq='M')).fillna(0)
monthly.index.name = 'bulan'
category = item_detail.groupby('category').agg(units=('order_item_id','size'),
    item_sales=('price','sum'), orders=('order_id','nunique')).sort_values('item_sales',ascending=False)
category['sales_share_pct'] = category['item_sales']/category['item_sales'].sum()*100
state = sales_orders.groupby('customer_state').agg(orders=('order_id','nunique'),
    item_sales=('item_sales','sum'),average_order_value=('item_sales','mean')).sort_values('orders',ascending=False)
state['order_share_pct'] = state['orders']/state['orders'].sum()*100
shipping_summary = delivery.groupby('is_late').agg(orders=('order_id','size'),
    median_delivery_days=('delivery_days','median'))
shipping_summary['share_pct'] = shipping_summary['orders']/len(delivery)*100
review_summary = reviewed.groupby('is_late').agg(reviewed_orders=('order_id','size'),
    mean_score=('review_score','mean'),low_score_pct=('low_score',lambda x:x.mean()*100))
review_summary['review_coverage_pct'] = review_summary['reviewed_orders']/shipping_summary['orders']*100
display(monthly)
display(category.head(10))
display(state.head(10))
display(shipping_summary.join(review_summary))
# Rekonsiliasi nilai agregat: detail barang harus sama dengan total pada pesanan.
assert np.isclose(item_detail['price'].sum(), sales_orders['item_sales'].sum())
assert monthly['orders'].sum() == len(sales_orders)
for name,table in {'inventory':inventory,'assessment':assessment,'missing_detail':missing_detail,
    'coverage':coverage,'monthly':monthly,'category':category,'state':state,
    'shipping_review':shipping_summary.join(review_summary)}.items():
    table.to_csv(RESULTS/f'{name}.csv',index=True)

# ## 7. Visualization & Explanation
# Grafik pertama membandingkan tren pesanan dan nilai barang dengan sumbu terpisah. Grafik kategori dan wilayah memakai 10 peringkat teratas; tabel CSV menyimpan keseluruhan hasil. Hasil historis tidak otomatis merupakan prediksi periode mendatang.

fig, axes = plt.subplots(2,1,figsize=(12,8),sharex=True)
x = monthly.index.astype(str)
axes[0].plot(x,monthly['orders'],marker='o',color='#2563eb')
axes[0].set(ylabel='Jumlah pesanan',title='Pesanan delivered menurut bulan pembelian')
axes[1].plot(x,monthly['item_sales']/1e6,marker='o',color='#0f766e')
axes[1].set(ylabel='Nilai barang (juta BRL)',xlabel='Bulan pembelian')
axes[1].tick_params(axis='x',rotation=60)
fig.tight_layout(); fig.savefig(RESULTS/'01_tren_bulanan.png',dpi=160); plt.show()
print('Bulan pesanan tertinggi:',monthly['orders'].idxmax(), int(monthly['orders'].max()))
print('Bulan nilai barang tertinggi:',monthly['item_sales'].idxmax(),round(monthly['item_sales'].max(),2))

fig, axes = plt.subplots(1,2,figsize=(14,6))
category.head(10).sort_values('item_sales')['item_sales'].div(1e6).plot.barh(ax=axes[0],color='#0f766e')
axes[0].set(title='10 kategori dengan nilai barang terbesar',xlabel='Juta BRL',ylabel='Kategori')
state.head(10).sort_values('orders')['orders'].plot.barh(ax=axes[1],color='#2563eb')
axes[1].set(title='10 negara bagian dengan pesanan terbanyak',xlabel='Pesanan delivered',ylabel='Negara bagian pelanggan')
fig.tight_layout(); fig.savefig(RESULTS/'02_kategori_wilayah.png',dpi=160); plt.show()
print('Kategori nilai terbesar:', category.index[0], '; kontribusi:', round(category.iloc[0]['sales_share_pct'],2),'%')
print('Kategori unit terbesar:',category['units'].idxmax(),int(category['units'].max()))
print('Wilayah pesanan terbesar:',state.index[0],'; kontribusi:',round(state.iloc[0]['order_share_pct'],2),'%')
print('Wilayah nilai terbesar:',state['item_sales'].idxmax())

fig, axes = plt.subplots(1,3,figsize=(14,4.8))
labels=['Tepat waktu','Terlambat']
s = shipping_summary.reindex([False,True]); r = review_summary.reindex([False,True])
axes[0].bar(labels,s['share_pct'],color=['#0f766e','#ea580c']); axes[0].set(ylabel='Persentase (%)',title='Status pengiriman',ylim=(0,100))
axes[1].bar(labels,r['mean_score'],color=['#0f766e','#ea580c']); axes[1].set(ylabel='Rata-rata skor',title='Skor ulasan (1–5)',ylim=(0,5))
axes[2].bar(labels,r['low_score_pct'],color=['#0f766e','#ea580c']); axes[2].set(ylabel='Persentase skor 1–2 (%)',title='Proporsi ulasan rendah',ylim=(0,100))
for ax, values in zip(axes,[s['share_pct'],r['mean_score'],r['low_score_pct']]):
    for i,v in enumerate(values): ax.text(i,v+0.8 if ax!=axes[1] else v+0.05,f'{v:.2f}',ha='center')
fig.tight_layout(); fig.savefig(RESULTS/'03_pengiriman_ulasan.png',dpi=160); plt.show()
print('Keterlambatan:',int(s.loc[True,'orders']),'dari',len(delivery),'pesanan; ',round(s.loc[True,'share_pct'],2),'%')
print('Perbedaan rerata skor (tepat waktu - terlambat):',round(r.loc[False,'mean_score']-r.loc[True,'mean_score'],2))
print('Perbedaan proporsi skor rendah (terlambat - tepat waktu), poin persentase:',round(r.loc[True,'low_score_pct']-r.loc[False,'low_score_pct'],2))

# ### Penjelasan interpretasi
# Nilai barang per kategori mengukur kontribusi penjualan bruto item, bukan profitabilitas. Jumlah unit dihitung dari baris order_item_id, bukan jumlah produk unik. Jumlah pesanan per kategori tidak dapat dijumlahkan untuk memperoleh total pesanan karena satu pesanan dapat berisi beberapa kategori.
# 
# Perbedaan skor antara kelompok pengiriman menunjukkan **asosiasi deskriptif**, bukan bukti bahwa keterlambatan menyebabkan skor rendah. Jenis produk, penjual, wilayah, dan masalah pesanan dapat ikut memengaruhi hasil. Hanya pesanan dengan skor tersedia masuk perbandingan; cakupan ulasan dilaporkan agar denominator jelas. Tidak dihitung korelasi biasa antara hari keterlambatan dan skor sebagai bukti sebab-akibat.

# ## 8. Analisis Lanjutan (Opsional): Segmentasi RFM
# Unit analisis adalah customer_unique_id. Recency = jumlah hari sejak pembelian terakhir hingga 1 September 2018; Frequency = jumlah pesanan delivered; Monetary = nilai barang delivered. Karena banyak pelanggan hanya memiliki satu pesanan, hindari qcut Frequency yang memaksa kelompok kuantil pada banyak nilai sama.
# 
# Aturan operasional, bukan klasifikasi universal: pelanggan berulang (Frequency ≥2); pelanggan baru/aktif satu transaksi (Frequency=1, Recency≤90); pelanggan satu transaksi yang sudah lama tidak aktif (Frequency=1, Recency>90). Pelanggan berulang ditambah tanda recent/stale menggunakan ambang 90 hari untuk menentukan prioritas retensi. Hasil bukan CLV dan tidak mencakup riwayat di luar periode.

snapshot = END
rfm = sales_orders.groupby('customer_unique_id').agg(
    last_purchase=('order_purchase_timestamp','max'),Frequency=('order_id','nunique'),Monetary=('item_sales','sum'))
rfm['Recency'] = (snapshot-rfm['last_purchase'].dt.normalize()).dt.days
rfm['segment'] = np.select([rfm['Frequency'].ge(2), rfm['Recency'].le(90)],
    ['Berulang','Satu transaksi - aktif'], default='Satu transaksi - lama')
rfm['recent_90_days'] = rfm['Recency'].le(90)
segment = rfm.groupby('segment').agg(customers=('Frequency','size'),
    median_recency=('Recency','median'),mean_frequency=('Frequency','mean'),
    total_item_sales=('Monetary','sum'))
segment['customer_share_pct'] = segment['customers']/len(rfm)*100
display(segment)
print('Pelanggan berulang (%) dalam jendela observasi:',round(rfm['Frequency'].ge(2).mean()*100,2))
print('Pelanggan berulang aktif 90 hari terakhir:',int((rfm['Frequency'].ge(2)&rfm['recent_90_days']).sum()))
rfm.reset_index().to_csv(RESULTS/'rfm.csv',index=False)
segment.to_csv(RESULTS/'rfm_summary.csv')
fig, ax = plt.subplots(figsize=(9,4))
segment['customers'].sort_values().plot.barh(ax=ax,color='#7c3aed')
ax.set(title='Segmentasi pelanggan dalam periode observasi',xlabel='Pelanggan unik',ylabel='Segmen')
fig.tight_layout();fig.savefig(RESULTS/'04_rfm.png',dpi=160);plt.show()

# ## 9. Conclusion & Recommendation
# ### Kesimpulan
# 1. Periode Januari 2017–Agustus 2018 memiliki **96,211 pesanan delivered dengan nilai barang tersedia**, dengan total nilai barang **BRL 13,181,027.13**. Pesanan tertinggi terjadi pada **2017-11** sebanyak **7,289 pesanan**; nilai barang tertinggi terjadi pada **2017-11** sebesar **BRL 987,765.37**. Puncak satu bulan tidak cukup untuk membuktikan pola musiman tahunan.
# 2. Kategori nilai barang terbesar adalah **health_beauty**, dengan nilai **BRL 1,229,557.50** dan kontribusi **9.33%**. Kategori dengan unit terbanyak adalah **bed_bath_table** (10,945 unit). Kategori unggulan berdasarkan nilai dan volume dapat berbeda.
# 3. Negara bagian **SP** mencatat **40,406 pesanan**, atau **42.00%** dari pesanan pada analisis penjualan. Negara bagian dengan nilai barang tertinggi adalah **SP**. Angka ini menggambarkan lokasi pelanggan, bukan lokasi penjual.
# 4. Sebanyak **6,531 dari 96,203 pesanan** dengan tanggal pengiriman valid terlambat (**6.79%**). Rerata skor pada pesanan berulasan adalah **4.29** untuk tepat waktu dan **2.27** untuk terlambat. Proporsi skor 1–2 masing-masing **9.25%** dan **62.42%**. Keterlambatan berkaitan dengan skor yang lebih rendah dalam data ini.
# 5. Di antara **93,104 pelanggan unik** yang dianalisis, **3.00%** memiliki minimal dua pesanan delivered dalam periode. Persentase ini bukan tingkat retensi seluruh masa hidup pelanggan.
# 
# ### Rekomendasi
# - **Persediaan dan penjualan:** jadikan kategori nilai dan volume tertinggi sebagai prioritas evaluasi stok. Gunakan tren bulanan sebagai dasar perencanaan awal; periksa margin, biaya simpan, dan ketersediaan sebelum menambah stok. Pantau stockout dan nilai barang bulanan.
# - **Distribusi:** prioritaskan evaluasi kapasitas pengiriman untuk negara bagian dengan permintaan terbesar. Hitung ongkir per pesanan dan lead time sebelum mengubah jaringan gudang; volume besar sendiri belum membuktikan kebutuhan gudang baru.
# - **Kualitas pengiriman:** audit rute/penjual yang sering terlambat, perbaiki estimasi tanggal, dan lakukan pemberitahuan proaktif. Pantau persentase keterlambatan dan proporsi ulasan rendah. Besaran target penurunan ditetapkan setelah uji operasional, bukan diasumsikan dari analisis deskriptif.
# - **Retensi:** uji penawaran pembelian kedua untuk pelanggan satu transaksi yang masih aktif dan kampanye reaktivasi untuk yang lama. Gunakan kelompok kontrol serta ukur konversi pembelian kedua dan margin setelah promosi.
# 
# ### Batasan
# Data merupakan snapshot historis: status delivered adalah status saat dataset dibuat. Bulan terbaru dapat belum matang dan pelanggan yang baru masuk memiliki waktu lebih pendek untuk mengulang pembelian. Perbandingan bulan tidak mengukur pertumbuhan like-for-like; sebagian order tanpa tanggal/skor tidak masuk analisis pengiriman/ulasan. Tidak ada informasi biaya, laba, inventori, paparan promosi, atau pembatalan setelah snapshot. Tidak dilakukan klaim kausal atau peramalan. Sebelum penggunaan bisnis terkini, ulangi analisis dengan data terbaru dan jendela observasi yang konsisten.

# ## 10. Pemeriksaan Reproduksibilitas
# Notebook ini telah dijalankan berurutan terhadap ZIP yang diunggah. Pemeriksaan mencakup keunikan key, validasi join, rekonsiliasi nilai barang detail terhadap agregat pesanan, dan rekonsiliasi jumlah pesanan bulanan. Semua grafik dan tabel dihasilkan oleh kode dalam notebook. `analysis.py` memuat kode yang sama dalam format script; `laporan_analisis.html` menampilkan kode, hasil, dan penjelasan tanpa perlu menjalankan Python. Tidak ada proses menghapus seluruh baris yang mengandung missing value.
