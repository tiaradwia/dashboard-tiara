# Proyek Analisis E-Commerce

Buka laporan_analisis.html untuk membaca hasil lengkap. Notebook proyek_analisis_ecommerce.ipynb berisi kode dan output.

1. Letakkan ZIP asli E-commerce-public-dataset(1).zip pada direktori proyek.
2. Pasang dependensi: `pip install -r requirements.txt`.
3. Jalankan `python analysis.py` atau buka notebook dan Run All.
4. Jika ZIP berada di tempat lain, ubah DATA_PATH di notebook atau set ECOMMERCE_ZIP.
5. Hasil diekspor ke hasil_analisis/.

ZIP dataset asli tidak disertakan ulang dalam paket proyek. Gunakan ZIP yang Anda unggah. Tidak perlu mengunduh data dari internet.
