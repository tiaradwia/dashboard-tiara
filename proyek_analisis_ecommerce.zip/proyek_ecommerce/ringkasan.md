## 9. Conclusion & Recommendation
### Kesimpulan
1. Periode Januari 2017–Agustus 2018 memiliki **96,211 pesanan delivered dengan nilai barang tersedia**, dengan total nilai barang **BRL 13,181,027.13**. Pesanan tertinggi terjadi pada **2017-11** sebanyak **7,289 pesanan**; nilai barang tertinggi terjadi pada **2017-11** sebesar **BRL 987,765.37**. Puncak satu bulan tidak cukup untuk membuktikan pola musiman tahunan.
2. Kategori nilai barang terbesar adalah **health_beauty**, dengan nilai **BRL 1,229,557.50** dan kontribusi **9.33%**. Kategori dengan unit terbanyak adalah **bed_bath_table** (10,945 unit). Kategori unggulan berdasarkan nilai dan volume dapat berbeda.
3. Negara bagian **SP** mencatat **40,406 pesanan**, atau **42.00%** dari pesanan pada analisis penjualan. Negara bagian dengan nilai barang tertinggi adalah **SP**. Angka ini menggambarkan lokasi pelanggan, bukan lokasi penjual.
4. Sebanyak **6,531 dari 96,203 pesanan** dengan tanggal pengiriman valid terlambat (**6.79%**). Rerata skor pada pesanan berulasan adalah **4.29** untuk tepat waktu dan **2.27** untuk terlambat. Proporsi skor 1–2 masing-masing **9.25%** dan **62.42%**. Keterlambatan berkaitan dengan skor yang lebih rendah dalam data ini.
5. Di antara **93,104 pelanggan unik** yang dianalisis, **3.00%** memiliki minimal dua pesanan delivered dalam periode. Persentase ini bukan tingkat retensi seluruh masa hidup pelanggan.

### Rekomendasi
- **Persediaan dan penjualan:** jadikan kategori nilai dan volume tertinggi sebagai prioritas evaluasi stok. Gunakan tren bulanan sebagai dasar perencanaan awal; periksa margin, biaya simpan, dan ketersediaan sebelum menambah stok. Pantau stockout dan nilai barang bulanan.
- **Distribusi:** prioritaskan evaluasi kapasitas pengiriman untuk negara bagian dengan permintaan terbesar. Hitung ongkir per pesanan dan lead time sebelum mengubah jaringan gudang; volume besar sendiri belum membuktikan kebutuhan gudang baru.
- **Kualitas pengiriman:** audit rute/penjual yang sering terlambat, perbaiki estimasi tanggal, dan lakukan pemberitahuan proaktif. Pantau persentase keterlambatan dan proporsi ulasan rendah. Besaran target penurunan ditetapkan setelah uji operasional, bukan diasumsikan dari analisis deskriptif.
- **Retensi:** uji penawaran pembelian kedua untuk pelanggan satu transaksi yang masih aktif dan kampanye reaktivasi untuk yang lama. Gunakan kelompok kontrol serta ukur konversi pembelian kedua dan margin setelah promosi.

### Batasan
Data merupakan snapshot historis: status delivered adalah status saat dataset dibuat. Bulan terbaru dapat belum matang dan pelanggan yang baru masuk memiliki waktu lebih pendek untuk mengulang pembelian. Perbandingan bulan tidak mengukur pertumbuhan like-for-like; sebagian order tanpa tanggal/skor tidak masuk analisis pengiriman/ulasan. Tidak ada informasi biaya, laba, inventori, paparan promosi, atau pembatalan setelah snapshot. Tidak dilakukan klaim kausal atau peramalan. Sebelum penggunaan bisnis terkini, ulangi analisis dengan data terbaru dan jendela observasi yang konsisten.
